<footer id="footer">
<div class="container">
<section class="links">
<div class="row">
<section class="3u 6u(medium) 12u$(small)">
<h3>Found Truck</h3>
<ul class="unstyled">
<li><a href="/">Página principal</a></li>
<li><a href="/">Rastreio rápido</a></li>
	
</ul>
</section>
<section class="3u 6u$(medium) 12u$(small)">
<h3>Procure parceiros</h3>
<ul class="unstyled">
<li><a href="parceiros.html">Pesquisar</a></li>
<li><a href="parceiros.html">Filtrar</a></li>
<li><a href="parceiros.html">Listar</a></li>
	
</ul>
</section>
<section class="3u 6u(medium) 12u$(small)">
<h3>Seja um parceiro</h3>
<ul class="unstyled">
<li><a href="CadastroFoodtruck.html">Cadastre-se</a></li>
<li><a href="/">Entre</a></li>
	
</ul>
</section>
<section class="3u$ 6u$(medium) 12u$(small)">
<h3>Sobre a equipe</h3>
<ul class="unstyled">
<li><a href="ContatoSobre.html">Sobre a equipe Foundtruck</a></li>
<li><a href="ContatoSobre.html">Contate-nos</a></li>
	
</ul>
</section>
</div>
</section>
<div class="row">
<div class="8u 12u$(medium)">
<ul class="copyright">
<li>&copy; FoundTruck. Todos os Direitos Reservados</li>
<li>Desenvolvimento: <a href="http://www.uniceub.br" title="Turma de Ciência da Computação - 5º Período">TCC - UniCEUB</a></li>
<li>Images: <a href="http://unsplash.com">Unsplash</a></li>
</ul>
</div>
<div class="4u$ 12u$(medium)">
<ul class="icons">
<li>
<a class="icon rounded icon-facebook"><span class="label">Facebook</span></a>
</li>
<li>
<a class="icon rounded icon-twitter"><span class="label">Twitter</span></a>
</li>
<li>
<a class="icon rounded icon-google-plus"><span class="label">Google+</span></a>
</li>
<li>
<a class="icon rounded icon-linkedin"><span class="label">LinkedIn</span></a>
</li>
</ul>
</div>
</div>
</div>
</footer>